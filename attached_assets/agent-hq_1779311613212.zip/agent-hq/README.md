# Agent HQ

A multi-tenant chassis for running marketing agents that do the research,
drafting, and proposing while a human approves anything that **spends money** or
**publishes in public**. Onit is org #1 (the dogfood); the architecture is
tenant-clean from line one so adding org #2 is a data row, not a rewrite.

This is the **P0 skeleton**: the platform plus exactly one read-only agent
(market intelligence) running end to end. Prove the chassis here before adding
agents that take actions.

---

## Run it (zero setup)

```bash
pip install -r requirements.txt
cp .env.example .env

python -m scripts.seed     # creates Onit (org #1), an admin user, the agent, guardrails
python -m scripts.smoke    # proves the whole spine + tenant isolation

# API + worker (two terminals)
uvicorn app.main:app --reload --port 8000
python -m app.worker
```

Trigger a run and read the brief:

```bash
curl -s -XPOST localhost:8000/api/runs -H 'X-Dev-User-Email: jordan@onit.com' \
     -H 'content-type: application/json' -d '{"agent_key":"market_intel"}'
# ...worker picks it up...
curl -s localhost:8000/api/runs -H 'X-Dev-User-Email: jordan@onit.com'
curl -s localhost:8000/api/runs/<RUN_ID> -H 'X-Dev-User-Email: jordan@onit.com'
```

Defaults to SQLite. On Replit, set `DATABASE_URL` to Postgres and run
`sql/schema.sql` (which also installs RLS).

---

## How it fits together

```
trigger (API or cron) ─► Run(queued) + Job(queued)
                                  │
                          worker leases job
                                  │
                 builds tenant-scoped AgentContext
                                  │
                        agent.run(ctx) ─► AgentResult
                                  │
        artifacts ──┐     proposed_actions ──┐
                    ▼                         ▼
              stored + cited        guardrail check ─► approval queue
                                                            │
                                                   human approve / reject
```

- **The contract** (`app/schemas.py`) — `AgentContext` in, `AgentResult` out.
  This is the seam that makes "bring your own agent" a v3 config change
  (`kind="http"`/`"mcp"`) rather than a rewrite. Lock it down now.
- **The approval queue** (`app/api/review.py`) is the product. Everything else
  is plumbing.
- **The five usability fundamentals** live in `app/worker.py`: observability
  (logs + `audit_log`), idempotent/leased jobs, guardrail gating before any
  side-effect, cost capture on every run, and graceful failure (a bad run is
  marked failed; the loop never crashes).

## Tenancy

`org_id` is on every tenant table. `app/tenancy.py::scoped()` refuses to build a
query without an `org_id`, so a forgotten filter fails loudly. Postgres RLS
(`sql/schema.sql`) is the belt-and-suspenders on top. **Never** key tenancy off
client input — it's derived from the SSO-verified email domain.

## Swapping the stub for real data

`app/data_sources/base.py` defines `MarketDataSource`. Today the agent uses
`StubMarketDataSource`. To go live, write `ZoomInfoDataSource` /
`ApolloDataSource` implementing the same interface and return them from
`app/worker.py::_resolve_market_data`. The agent never changes.

## Auth

Dev trusts the `X-Dev-User-Email` header (or `DEV_AUTH_EMAIL`). For prod, replace
`app/auth.py::current_user` with Google Workspace SSO: verify the `hd` domain
claim against `ALLOWED_EMAIL_DOMAINS`, then derive the org from the domain.

---

## Roadmap

- **P0 (this skeleton)** — chassis + market-intel agent, end to end. ✅
- **P1** — harden the five fundamentals, build the review UI, onboard the Onit team.
- **P2** — first action-taking agent: content engine (publish gate) + spend
  guardrails; wire real ZoomInfo/Apollo behind the data-source seam.
- **P3** — open the registry: teammates register `http`/`mcp` agents. (Untrusted-code
  sandboxing only matters once outside parties write agents — deferred until then.)

## What is deliberately NOT here yet

Real OAuth, encrypted token storage at rest, the review **UI** (only the API),
ad-platform clients, action executors, and a scheduler process for the cron
field. All are P1–P2. The point of P0 is a trustworthy spine you can build on.
```
