from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_env: str = "dev"
    database_url: str = "sqlite:///./agenthq.db"

    dev_auth_bypass: bool = True
    dev_auth_email: str = "jordan@onit.com"
    allowed_email_domains: str = "onit.com"

    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-6"

    worker_poll_seconds: float = 2.0

    @property
    def allowed_domains(self) -> list[str]:
        return [d.strip().lower() for d in self.allowed_email_domains.split(",") if d.strip()]

    @property
    def is_sqlite(self) -> bool:
        return self.database_url.startswith("sqlite")


@lru_cache
def get_settings() -> Settings:
    return Settings()
