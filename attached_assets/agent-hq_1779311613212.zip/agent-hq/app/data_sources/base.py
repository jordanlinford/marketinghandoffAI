"""
MarketDataSource is the interface the market-intel agent depends on. The agent
NEVER imports ZoomInfo or Apollo directly — it talks to this interface, so the
stub (today) and the live clients (later) are interchangeable. Wiring real APIs
becomes a swap behind this seam, not a change to the agent.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class CompanyRecord:
    name: str
    employees: int
    revenue_usd: float
    industry: str
    fit_score: float        # 0..1, how well it matches the ICP
    intent_score: float     # 0..1, in-market signal strength
    source: str = "stub"


@dataclass
class KeywordRecord:
    term: str
    monthly_volume: int
    difficulty: int         # 0..100
    intent: str             # informational | commercial | transactional
    source: str = "stub"


@dataclass
class MarketDataSource(ABC):
    @abstractmethod
    def find_companies(self, icp: dict, limit: int = 100) -> list[CompanyRecord]: ...

    @abstractmethod
    def keyword_universe(self, seeds: list[str], limit: int = 50) -> list[KeywordRecord]: ...
