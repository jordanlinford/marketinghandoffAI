"""
Postgres/SQLite-backed job queue. Deliberately boring: a `jobs` table the worker
polls. Robust and debuggable for a team-sized load. When you outgrow a single
worker, swap this for a real queue + worker pool — the enqueue/lease interface
stays the same.
"""
from __future__ import annotations

from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import Job, _now


def enqueue(db: Session, org_id: str, kind: str, payload: dict) -> Job:
    job = Job(org_id=org_id, kind=kind, payload=payload, status="queued")
    db.add(job)
    db.commit()
    db.refresh(job)
    return job


def lease_next(db: Session, lease_seconds: int = 120) -> Job | None:
    """Atomically claim the next queued job. Uses SKIP LOCKED on Postgres so
    multiple workers never grab the same job; on SQLite (single worker) the
    immediate transaction is sufficient."""
    settings = get_settings()
    stmt = select(Job).where(Job.status == "queued").order_by(Job.created_at).limit(1)
    if not settings.is_sqlite:
        stmt = stmt.with_for_update(skip_locked=True)

    job = db.execute(stmt).scalar_one_or_none()
    if job is None:
        return None
    job.status = "leased"
    job.attempts += 1
    job.lease_until = _now() + timedelta(seconds=lease_seconds)
    db.commit()
    db.refresh(job)
    return job


def complete(db: Session, job: Job, error: str | None = None) -> None:
    job.status = "error" if error else "done"
    job.last_error = error
    db.commit()
