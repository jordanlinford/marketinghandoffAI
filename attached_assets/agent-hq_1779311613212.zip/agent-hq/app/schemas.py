"""
The agent contract.

This is the seam that keeps the platform extensible. Every agent — whether a
first-party Python class today, or a teammate's HTTP/MCP endpoint tomorrow —
takes an AgentContext and returns an AgentResult. Lock this schema down and you
never have to retrofit "bring your own agent."

  AgentContext  : runtime, in-memory, rich (live data-source handles, logger).
                  A dataclass, not persisted.
  AgentResult   : serializable output, persisted as Run + Artifacts + Proposals.
                  Pydantic, so it round-trips cleanly to/from JSON (and over
                  HTTP to a remote agent).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from pydantic import BaseModel, Field


# ---- Serializable output (the contract's return type) ---------------------
class Citation(BaseModel):
    source: str
    url: str | None = None
    snippet: str | None = None


class ArtifactDraft(BaseModel):
    type: str                       # market_brief | email_copy | ad_copy | blog_post ...
    title: str
    body: dict[str, Any] = Field(default_factory=dict)
    citations: list[Citation] = Field(default_factory=list)


class ProposedAction(BaseModel):
    """A side-effect the agent wants to take. Never executed without a gate."""
    action_type: str                # publish_blog | set_campaign_budget ...
    payload: dict[str, Any] = Field(default_factory=dict)
    reasoning: str = ""
    guardrail_scope: str | None = None   # "spend" | "publish" | None


class AgentResult(BaseModel):
    artifacts: list[ArtifactDraft] = Field(default_factory=list)
    proposed_actions: list[ProposedAction] = Field(default_factory=list)
    cost_usd: float = 0.0
    logs: list[str] = Field(default_factory=list)


# ---- Runtime input (rich; not persisted) ----------------------------------
@dataclass
class AgentContext:
    org_id: str
    org_name: str
    agent_key: str
    registration_id: str
    run_id: str
    trigger: str = "manual"
    task: dict[str, Any] = field(default_factory=dict)
    brand_guide: dict[str, Any] = field(default_factory=dict)
    icp: dict[str, Any] = field(default_factory=dict)
    config: dict[str, Any] = field(default_factory=dict)
    prior_artifacts: list[dict[str, Any]] = field(default_factory=list)
    # Scoped service handles, injected by the worker. Agents NEVER open their
    # own DB sessions or read another org's connections — they get what the
    # worker hands them, already tenant-scoped.
    get_market_data: Callable[[], Any] | None = None
    log: Callable[[str], None] = lambda msg: None


# ---- API DTOs --------------------------------------------------------------
class TriggerRunIn(BaseModel):
    agent_key: str
    task: dict[str, Any] = Field(default_factory=dict)


class RunOut(BaseModel):
    id: str
    agent_key: str
    status: str
    trigger: str
    cost_usd: float
    error: str | None = None
    created_at: str

    @classmethod
    def of(cls, r) -> "RunOut":
        return cls(
            id=r.id, agent_key=r.agent_key, status=r.status, trigger=r.trigger,
            cost_usd=r.cost_usd, error=r.error, created_at=r.created_at.isoformat(),
        )


class ProposalDecisionIn(BaseModel):
    note: str = ""
